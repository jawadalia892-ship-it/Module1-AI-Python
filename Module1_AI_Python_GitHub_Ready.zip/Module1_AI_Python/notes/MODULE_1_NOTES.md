# Module 1 Notes — Introduction to AI & Python

## 1. What is Artificial Intelligence?

Artificial Intelligence (AI) is the field of computer science focused on building systems that can perform tasks that normally require human intelligence.

Examples:
- Voice assistants
- Recommendation systems
- Image recognition
- Chatbots
- Fraud detection
- Navigation systems

### AI in daily life
AI can recommend videos, detect spam emails, translate languages, recognize faces, and help doctors analyze medical images.

---

## 2. AI vs Machine Learning vs Deep Learning

### Artificial Intelligence
AI is the broad field of making machines perform intelligent tasks.

### Machine Learning
ML is a subset of AI where computers learn patterns from data instead of being explicitly programmed for every rule.

Example:
A spam detector learns from examples of spam and normal emails.

### Deep Learning
Deep Learning is a subset of ML that uses multi-layer neural networks.

Example:
Modern image recognition and many speech-recognition systems use deep learning.

### Simple relationship

**AI → Machine Learning → Deep Learning**

---

## 3. Real-World AI Applications

### Healthcare
- Medical image analysis
- Patient risk prediction
- Drug discovery support

### Education
- Personalized learning
- Automated feedback
- AI tutoring systems

### Finance
- Fraud detection
- Credit risk analysis
- Customer support chatbots

### E-commerce
- Product recommendations
- Search ranking
- Demand forecasting

### Transportation
- Route optimization
- Driver-assistance systems
- Traffic prediction

---

## 4. Python

Python is a high-level programming language known for readable syntax and a large ecosystem.

Python is widely used in:
- AI
- Machine Learning
- Data Science
- Web development
- Automation
- Scripting

---

## 5. Variables and Data Types

A variable stores a value.

```python
name = "Salar"
age = 21
height = 5.8
is_student = True
```

Common data types:
- `str` — text
- `int` — whole numbers
- `float` — decimal numbers
- `bool` — True/False
- `list` — ordered collection

---

## 6. Conditions

Conditions allow a program to make decisions.

```python
marks = 85

if marks >= 50:
    print("Pass")
else:
    print("Fail")
```

Operators:
- `>` greater than
- `<` less than
- `>=` greater than or equal
- `<=` less than or equal
- `==` equal
- `!=` not equal

---

## 7. Loops

Loops repeat code.

### For loop

```python
for number in range(1, 6):
    print(number)
```

### While loop

```python
count = 1

while count <= 5:
    print(count)
    count += 1
```

---

## 8. Lists

A list stores multiple values.

```python
books = ["Python", "AI", "ML"]

print(books[0])
books.append("Deep Learning")
```

Useful methods:
- `append()`
- `remove()`
- `sort()`
- `len()`

---

## 9. Functions

A function is a reusable block of code.

```python
def greet(name):
    return f"Hello, {name}!"

print(greet("Salar"))
```

Functions make programs easier to organize and reuse.

---

## 10. Beginner Practice Programs

Recommended programs:
1. Add two numbers
2. Calculate Celsius to Fahrenheit
3. Find area of a rectangle
4. Check even or odd
5. Check pass/fail
6. Print numbers 1–10
7. Find the largest number
8. Calculate average marks
9. Simple calculator
10. Student grade calculator

---

## 11. Key Takeaways

- AI is the broad concept of intelligent machines.
- ML allows systems to learn patterns from data.
- DL uses multi-layer neural networks.
- Python is widely used in AI and ML.
- Variables store values.
- Conditions make decisions.
- Loops repeat tasks.
- Lists store collections.
- Functions organize reusable logic.

## Self-Assessment

Before completing Module 1, I should be able to:
- [ ] Explain AI, ML, and DL in simple words.
- [ ] Give at least five real-world AI examples.
- [ ] Create Python variables.
- [ ] Use `if/else`.
- [ ] Write `for` and `while` loops.
- [ ] Create and modify lists.
- [ ] Define and call functions.
- [ ] Build small Python programs.
