# Module 1 — Introduction to AI & Python

## Internship Module
**Level:** Beginner  
**Duration:** Day 1–Day 4

## Learning Objectives
- Understand Artificial Intelligence (AI), Machine Learning (ML), and Deep Learning (DL).
- Identify real-world AI applications.
- Set up and use Python.
- Practice variables, data types, conditions, loops, functions, and lists.
- Build beginner-friendly Python programs.

## Project Contents
```text
Module1_AI_Python/
├── README.md
├── notes/
│   └── MODULE_1_NOTES.md
├── python_practice/
│   ├── 01_variables_and_data_types.py
│   ├── 02_conditions.py
│   ├── 03_loops.py
│   ├── 04_lists.py
│   ├── 05_functions.py
│   └── 06_beginner_programs.py
└── requirements.txt
```

## How to Run
Install Python 3.x, then run any file:

```bash
python python_practice/01_variables_and_data_types.py
```

No external Python packages are required for this module.

## Learning Evidence
This repository contains:
- Structured Module 1 notes
- Python practice examples
- Beginner exercises
- Small real-world programs

## Author
Salar Ali
