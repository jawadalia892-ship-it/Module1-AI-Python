# Lists Practice

books = ["Python Basics", "Artificial Intelligence", "Machine Learning"]

print("Original list:", books)
print("First book:", books[0])

books.append("Deep Learning")
print("After append:", books)

books.remove("Python Basics")
print("After remove:", books)

print("Number of books:", len(books))
