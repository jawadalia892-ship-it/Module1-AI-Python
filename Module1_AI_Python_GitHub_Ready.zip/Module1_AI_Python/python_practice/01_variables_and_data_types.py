# Variables and Data Types

name = "Salar Ali"
age = 21
height = 5.8
is_student = True

print("Name:", name)
print("Age:", age)
print("Height:", height)
print("Student:", is_student)

print("\nData types:")
print(type(name))
print(type(age))
print(type(height))
print(type(is_student))
