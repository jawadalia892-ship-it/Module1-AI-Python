# Functions Practice

def greet(name):
    return f"Hello, {name}!"


def add_numbers(a, b):
    return a + b


def calculate_area(length, width):
    return length * width


print(greet("Salar"))
print("Sum:", add_numbers(10, 20))
print("Rectangle area:", calculate_area(5, 4))
