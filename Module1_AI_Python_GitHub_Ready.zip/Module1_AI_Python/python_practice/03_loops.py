# Loops Practice

print("For loop:")
for number in range(1, 11):
    print(number)

print("\nEven numbers from 1 to 20:")
for number in range(1, 21):
    if number % 2 == 0:
        print(number)

print("\nWhile loop:")
count = 1
while count <= 5:
    print("Count:", count)
    count += 1
