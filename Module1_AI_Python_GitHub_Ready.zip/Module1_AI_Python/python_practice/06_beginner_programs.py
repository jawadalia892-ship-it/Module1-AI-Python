# Beginner Python Programs

# 1. Add two numbers
a = 10
b = 20
print("1. Sum:", a + b)

# 2. Celsius to Fahrenheit
celsius = 30
fahrenheit = (celsius * 9 / 5) + 32
print("2. Fahrenheit:", fahrenheit)

# 3. Area of rectangle
length = 10
width = 5
print("3. Rectangle area:", length * width)

# 4. Even or odd
number = 17
if number % 2 == 0:
    print("4. Even")
else:
    print("4. Odd")

# 5. Largest of three numbers
x, y, z = 15, 42, 27
largest = max(x, y, z)
print("5. Largest:", largest)

# 6. Average marks
marks = [80, 75, 90, 85, 70]
average = sum(marks) / len(marks)
print("6. Average marks:", average)

# 7. Simple calculator
num1 = 20
num2 = 5
operator = "*"

if operator == "+":
    result = num1 + num2
elif operator == "-":
    result = num1 - num2
elif operator == "*":
    result = num1 * num2
elif operator == "/":
    result = num1 / num2
else:
    result = "Invalid operator"

print("7. Calculator result:", result)

# 8. Student grade
student_marks = 82

if student_marks >= 80:
    grade = "A"
elif student_marks >= 70:
    grade = "B"
elif student_marks >= 60:
    grade = "C"
elif student_marks >= 50:
    grade = "D"
else:
    grade = "F"

print("8. Student grade:", grade)
